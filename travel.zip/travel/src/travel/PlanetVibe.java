package travel;
import java.util.*;

public class PlanetVibe {

	//instant variables
	String bandName;
	String albumName;
	int yearReleased;
	
	//build constructor
	public PlanetVibe(String bandName, String albumName, int yearReleased) {
		this.bandName = bandName;
		this.albumName = albumName;
		this.yearReleased = yearReleased;
		
	}
	//generate 2 different greetings using if/else
	
	//1.band introduction method
	void TestGreeting() {
		if(bandName.equals("While She Sleeps") || bandName.equals("Escape The Fate")) {
			System.out.println("the band  " + this.bandName + " released a new album today.");
		}
		
	//2.no band 
		else {
			System.out.println("I never heard of this band");
		}
	}
	
	//this wil generate
	void album() {
		System.out.println("the new album: " + this.albumName);
	}
	
	
	void year() {
		switch (yearReleased) {
		case 2020:
			System.out.println("this album released 2020");
			for(int i =0; i<2 ; i++) {
				System.out.println("yuck, thats good");
			}
			break;
		case 2021:
			System.out.println("this album released 2021");
			for(int i =0; i<1 ; i++) {
				System.out.println("2021 baby, good year for music.");
			}
			break;
		case 2022:
			System.out.println("what is a crepe?");
			for(int i =0; i<4 ; i++) {
				System.out.println("this thing looks like a pancake");
			}
			break;
		case 2023:
			System.out.println("you want some gelato bro?");
			for(int i =0; i<1 ; i++) {
				System.out.println("that word sounds like jello dude");
			}
			break;
		default: 
			 System.out.println("you get NOTHING!");
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
