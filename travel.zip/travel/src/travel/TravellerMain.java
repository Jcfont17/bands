package travel;
import java.util.*;

public class TravellerMain {

	public static void main(String[] args) {
		String bandName;
		String albumName;
		int yearReleased;
		
		Scanner input = new Scanner(System.in);
		
		System.out.println("what is your band's name?");
		bandName = input.nextLine();
		System.out.println("what is your new album name brother?");
		albumName = input.nextLine();
		System.out.println("what is year was it released");
		yearReleased = input.nextInt();
		
		PlanetVibe obj1 = new PlanetVibe(bandName, albumName, yearReleased);
		obj1.TestGreeting();
		obj1.album();
		obj1.year();
	}

}
